module

public import KhanSL2.Conditional.Assembly

@[expose] public section

/-!
# The original specified-map theorem from collision support alone

`Conditional.RemainingInputs` has one field: the middle-degree collision-support
induction step. `Conditional.mainStatement_of_collisionSupport` proves the original
`MainStatement` directly from that step. No proof of collision support is asserted.

The actual BGG resolution and coefficient-homology comparison, canonical coefficient
action and linearity, finite generation and projectivity of all BGG terms,
rank-one top term, above-degree vanishing, depth descent, low-degree deformation
step, and finite-dimensional duality are proved. The distinct-evaluation/Teleman
branch needed to establish collision support remains open.
-/
